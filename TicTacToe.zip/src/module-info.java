module KolkoKrzyzyk2 {
}